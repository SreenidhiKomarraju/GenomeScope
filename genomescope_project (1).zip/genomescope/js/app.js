/* ============================================================
   GenomeScope — Main JavaScript
   Project: Structural Variation Detection from 3D Genome Data
   ============================================================ */

/* ─── STARFIELD ─── */
(function () {
  const container = document.getElementById('stars');
  for (let i = 0; i < 120; i++) {
    const star = document.createElement('div');
    star.className = 'star';
    const size = Math.random() * 2.5 + 0.5;
    star.style.cssText = `
      width:${size}px; height:${size}px;
      left:${Math.random() * 100}%;
      top:${Math.random() * 100}%;
      --d:${(Math.random() * 4 + 2).toFixed(1)}s;
      --o:${(Math.random() * 0.5 + 0.1).toFixed(2)};
      animation-delay:${(Math.random() * 5).toFixed(1)}s
    `;
    container.appendChild(star);
  }
})();


/* ─── PAGE NAVIGATION ─── */
function goPage(name) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-link').forEach(b => b.classList.remove('active'));
  document.getElementById('page-' + name).classList.add('active');
  const map = { home: 0, analyzer: 1, knowledge: 2, applications: 3, about: 4 };
  const links = [...document.querySelectorAll('.nav-link')];
  if (map[name] !== undefined) links[map[name]].classList.add('active');
  window.scrollTo(0, 0);
}


/* ─── DEMO DATASETS ─────────────────────────────────────────
   Each demo has:
     label  – shown in the log
     svs    – array of detected SV objects
     pattern – which heatmap pattern to draw ('del','dup','inv','tra','normal')
     risk    – LOW / MEDIUM / HIGH / CRITICAL
   ─────────────────────────────────────────────────────────── */
const DEMOS = {
  k562_del: {
    label: 'K562 — chr4 deletion (152–155 Mb)',
    svs: [
      { id: 'SV001', type: 'DEL', chr: 'chr4',  start: '152,540 kb', end: '155,680 kb', size: '3.1 Mb', conf: 0.98, disease: 'Leukemia (tumor suppressor loss)' },
      { id: 'SV002', type: 'DUP', chr: 'chr4',  start: '158,000 kb', end: '162,000 kb', size: '4.0 Mb', conf: 0.81, disease: 'Oncogene amplification (MYC)' },
    ],
    pattern: 'del',
    risk: 'HIGH'
  },

  k562_tra: {
    label: 'K562 — BCR-ABL translocation (chr9 ↔ chr22)',
    svs: [
      { id: 'SV001', type: 'TRA', chr: 'chr9→chr22', start: '133,700 kb', end: '—',         size: '—',      conf: 0.97, disease: 'CML — Philadelphia chromosome (BCR-ABL)' },
      { id: 'SV002', type: 'DEL', chr: 'chr9',       start: '135,000 kb', end: '135,800 kb', size: '800 kb', conf: 0.76, disease: 'Secondary deletion at translocation breakpoint' },
    ],
    pattern: 'tra',
    risk: 'CRITICAL'
  },

  gm_normal: {
    label: 'GM12878 — normal lymphoblastoid',
    svs: [
      { id: 'SV001', type: 'DUP', chr: 'chr1', start: '145,200 kb', end: '145,500 kb', size: '300 kb', conf: 0.42, disease: 'Low confidence — likely benign polymorphism' },
    ],
    pattern: 'normal',
    risk: 'LOW'
  },

  plant_inv: {
    label: 'Rice (Oryza sativa) — chr3 inversion',
    svs: [
      { id: 'SV001', type: 'INV', chr: 'chr3', start: '12,300 kb', end: '13,800 kb', size: '1.5 Mb', conf: 0.88, disease: 'Drought-tolerance locus (OsDREB) disruption' },
      { id: 'SV002', type: 'DEL', chr: 'chr3', start: '11,500 kb', end: '11,900 kb', size: '400 kb', conf: 0.72, disease: 'Yield-related gene cluster deletion' },
    ],
    pattern: 'inv',
    risk: 'MEDIUM'
  }
};

/* currently loaded dataset */
let currentDemo = null;
let currentSVs  = [];


/* ─── LOAD DEMO ─── */
function loadDemo(key) {
  currentDemo = DEMOS[key];
  showToast('Dataset loaded: ' + currentDemo.label);
  document.getElementById('empty-state').style.display = 'none';
}


/* ─── LOAD FILE ─── */
/* 
  In a real version this would parse the CSV and build a matrix.
  For the mini-project demo we fall back to the k562_del dataset
  so the UI always has something to show.
*/
function loadFile(input) {
  if (!input.files[0]) return;
  currentDemo = DEMOS['k562_del']; // fallback while real parser is added
  showToast('File loaded: ' + input.files[0].name + ' — click Run the analysis');
}


/* ─── RUN ANALYSIS ─── */
function runAnalysis() {
  const btn = document.getElementById('run-btn');
  btn.disabled = true;

  document.getElementById('progress-card').style.display = 'block';
  document.getElementById('results-area').style.display  = 'none';
  document.getElementById('metrics-row').style.display   = 'none';
  document.getElementById('empty-state').style.display   = 'none';

  const demo = currentDemo || DEMOS['k562_del'];

  /* pipeline step labels that scroll through the log */
  const steps = [
    'Loading contact matrix...',
    'Validating bin resolution (10 kb)...',
    'Applying ICE normalization...',
    'Computing observed / expected ratios...',
    'Running z-score anomaly scan...',
    'Running Isolation Forest (ML)...',
    'Applying saliency segmentation...',
    'Classifying candidate regions...',
    'Filtering false positives...',
    'Writing report...'
  ];

  const log = document.getElementById('prog-log');
  const bar = document.getElementById('prog-bar');
  log.innerHTML = '';
  bar.style.width = '0%';

  let i = 0;
  function nextStep() {
    if (i > 0) log.children[i - 1].className = 'log-line done';
    if (i < steps.length) {
      const line = document.createElement('div');
      line.className = 'log-line active';
      line.textContent = '▸ ' + steps[i];
      log.appendChild(line);
      log.scrollTop = log.scrollHeight;
      bar.style.width = ((i + 1) / steps.length * 100).toFixed(0) + '%';
      i++;
      setTimeout(nextStep, 200 + Math.random() * 250);
    } else {
      bar.style.width = '100%';
      setTimeout(() => showResults(demo), 400);
      btn.disabled = false;
    }
  }
  nextStep();
}


/* ─── SHOW RESULTS ─── */
function showResults(demo) {
  currentSVs = demo.svs;
  document.getElementById('results-area').style.display = 'block';
  document.getElementById('metrics-row').style.display  = 'grid';

  /* top metric cards */
  document.getElementById('m-svcount').textContent = demo.svs.length;
  const avgConf = (demo.svs.reduce((a, b) => a + b.conf, 0) / demo.svs.length * 100).toFixed(0) + '%';
  document.getElementById('m-conf').textContent = avgConf;
  const sizes = demo.svs.filter(s => s.size !== '—').map(s => parseFloat(s.size));
  document.getElementById('m-size').textContent = sizes.length ? Math.max(...sizes).toFixed(1) + ' Mb' : '—';

  const riskLabel = { LOW: 'LOW', MEDIUM: 'MED', HIGH: 'HIGH', CRITICAL: 'CRIT' };
  const riskColor = { LOW: 'var(--success)', MEDIUM: 'var(--warning)', HIGH: 'var(--danger)', CRITICAL: '#ff0040' };
  document.getElementById('m-risk').textContent    = riskLabel[demo.risk] || demo.risk;
  document.getElementById('m-risk').style.color    = riskColor[demo.risk] || 'var(--text)';

  drawHeatmaps(demo.pattern);
  drawTable(demo.svs);
  drawInterpretation(demo);
}


/* ─── HEATMAP RENDERING ──────────────────────────────────────
   We draw two <canvas> elements side-by-side:
     raw-canvas – normal contact map (distance-decay gradient)
     sv-canvas  – same map with SV hotspot blocks highlighted
   
   Algorithm:
     1. For each pixel (i,j) compute expected contact value based
        on genomic distance (j-i), adding a deterministic noise
        using a sin-based pseudo-random function.
     2. For sv-canvas, check if (i,j) falls inside a known SV
        region for the current dataset type and boost that value.
     3. Map the value → colour using heatColor().
   ─────────────────────────────────────────────────────────── */
function heatColor(v, highlight) {
  if (highlight) return `rgba(239,68,68,${Math.min(1, v * 1.3).toFixed(2)})`;
  if (v > 0.75)  return `rgba(214,90,48,${v.toFixed(2)})`;
  if (v > 0.45)  return `rgba(180,120,40,${v.toFixed(2)})`;
  if (v > 0.2)   return `rgba(30,80,160,${v.toFixed(2)})`;
  return          `rgba(10,18,40,${Math.max(0.15, v).toFixed(2)})`;
}

function drawHeatmaps(svType) {
  const raw = document.getElementById('raw-canvas');
  const svC = document.getElementById('sv-canvas');
  const N   = 40; // grid size (40×40 bins)

  [raw, svC].forEach(c => { c.width = N; c.height = N; });
  const rCtx = raw.getContext('2d');
  const sCtx = svC.getContext('2d');

  /* deterministic pseudo-random (no seed needed, same each call) */
  function seededRand(i, j) { return Math.abs((Math.sin(i * 127 + j * 311) * 43758.5453) % 1); }

  for (let i = 0; i < N; i++) {
    for (let j = i; j < N; j++) {
      const dist = j - i;
      /* distance-decay model: nearby = bright, far = dark */
      let v = Math.max(0, 1 - dist * 0.055) * (0.8 + seededRand(i, j) * 0.4);
      v = Math.max(0, Math.min(1, v + (seededRand(i + 99, j + 77) - 0.5) * 0.18));

      /* draw raw heatmap (symmetric — both triangles) */
      rCtx.fillStyle = heatColor(v, false);
      rCtx.fillRect(j, i, 1, 1);
      rCtx.fillRect(i, j, 1, 1);

      /* check if pixel falls inside an SV region for this type */
      let hot = false;
      if (svType === 'del') hot = (i >= 8  && i <= 14 && j >= 26 && j <= 32) || (i >= 26 && i <= 32 && j >= 8  && j <= 14);
      if (svType === 'dup') hot = (i >= 6  && i <= 12 && j >= 18 && j <= 24);
      if (svType === 'inv') hot = (Math.abs((i + j) - N + 2) <= 2 && i >= 10 && i <= 30);
      if (svType === 'tra') hot = (i >= 4  && i <= 9  && j >= 30 && j <= 36) || (i >= 30 && i <= 36 && j >= 4 && j <= 9);

      const sv_v = hot ? Math.min(1, v + 0.7) : v;
      sCtx.fillStyle = heatColor(sv_v, hot);
      sCtx.fillRect(j, i, 1, 1);
      sCtx.fillRect(i, j, 1, 1);
    }
  }
}


/* ─── SV TABLE ─── */
const typeClass = { DEL: 'type-del', DUP: 'type-dup', INV: 'type-inv', TRA: 'type-tra' };

function drawTable(svs) {
  const tbody = document.getElementById('sv-tbody');
  tbody.innerHTML = '';
  svs.forEach(sv => {
    const barColor = sv.conf > 0.8 ? '#22c55e' : sv.conf > 0.6 ? '#f59e0b' : '#ef4444';
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><span style="font-family:var(--font-mono);font-size:0.75rem;">${sv.id}</span></td>
      <td><span class="type-badge ${typeClass[sv.type] || 'type-del'}">${sv.type}</span></td>
      <td style="font-family:var(--font-mono);font-size:0.75rem;">${sv.chr}</td>
      <td style="font-family:var(--font-mono);font-size:0.75rem;">${sv.start}</td>
      <td style="font-family:var(--font-mono);font-size:0.75rem;">${sv.end}</td>
      <td style="font-family:var(--font-mono);font-size:0.75rem;color:var(--text2);">${sv.size}</td>
      <td>
        <div style="display:flex;align-items:center;gap:6px;">
          <div class="conf-bar">
            <div class="conf-fill" style="width:${(sv.conf * 100).toFixed(0)}%;background:${barColor};"></div>
          </div>
          <span style="font-family:var(--font-mono);font-size:0.75rem;color:${barColor};">${(sv.conf * 100).toFixed(0)}%</span>
        </div>
      </td>
      <td style="font-size:0.75rem;color:var(--text2);max-width:200px;">${sv.disease}</td>`;
    tbody.appendChild(tr);
  });
}


/* ─── INTERPRETATION TEXT ─── */
function drawInterpretation(demo) {
  const el = document.getElementById('interp-text');
  const messages = {
    LOW:
      `<span style="color:var(--success);font-weight:500;">Low-risk profile.</span>
       No high-confidence pathogenic SVs found. The one variant we flagged is most likely a common
       copy-number polymorphism rather than a disease-causing change. Routine follow-up is enough.`,
    MEDIUM:
      `<span style="color:var(--warning);font-weight:500;">Worth looking into.</span>
       We found an inversion overlapping a regulatory region. It doesn't change the protein sequence
       directly, but it could disrupt how that gene is switched on and off. Functional validation
       would be the next step before drawing any clinical conclusions.`,
    HIGH:
      `<span style="color:var(--danger);font-weight:500;">High-risk genomic profile.</span>
       Two strong signals — a deletion in a region associated with tumor suppressor genes, and a
       possible oncogene amplification. This is consistent with what you'd expect from K562, a
       leukemia cell line that's been extensively studied. These findings would need to be cross-
       checked against whole-genome sequencing before clinical use.`,
    CRITICAL:
      `<span style="color:#ff4060;font-weight:500;">Pathogenic rearrangement detected.</span>
       There's a very strong inter-chromosomal contact block between chr9 and chr22, right at the
       BCR and ABL1 gene loci. This is the Philadelphia chromosome translocation — t(9;22)(q34;q11.2)
       — the direct molecular cause of Chronic Myeloid Leukemia (CML).
       Imatinib (Gleevec) was specifically designed to block the BCR-ABL fusion protein this creates,
       and is the first-line treatment for this exact SV.`
  };

  el.innerHTML = messages[demo.risk] || 'Analysis complete.';
  el.innerHTML += `<br><br>
    <span style="color:var(--text3);font-size:0.8rem;">
      Dataset: ${demo.label} &middot;
      ${demo.svs.length} SV(s) detected &middot;
      Hybrid statistical + Isolation Forest pipeline
    </span>`;
}


/* ─── EXPORT CSV ─── */
function exportReport() {
  if (!currentSVs.length) { showToast('Run the analysis first'); return; }
  let csv = 'SV_ID,Type,Chr,Start,End,Size,Confidence,Disease_Link\n';
  currentSVs.forEach(sv => {
    csv += `${sv.id},${sv.type},${sv.chr},"${sv.start}","${sv.end}",${sv.size},${(sv.conf * 100).toFixed(0)}%,"${sv.disease}"\n`;
  });
  const blob = new Blob([csv], { type: 'text/csv' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'genomescope_sv_report.csv';
  a.click();
}


/* ─── TOAST NOTIFICATION ─── */
function showToast(msg) {
  const t = document.createElement('div');
  t.style.cssText = `
    position:fixed; bottom:1.5rem; right:1.5rem; z-index:9999;
    background:var(--surface2); border:1px solid var(--border2); border-radius:10px;
    padding:10px 18px; font-size:0.82rem; color:var(--text);
    animation:fadeUp 0.3s ease; box-shadow:0 4px 20px rgba(0,0,0,0.4);`;
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 3000);
}


/* ─── DRAG & DROP ─── */
const dropZone = document.getElementById('drop-zone');
if (dropZone) {
  dropZone.addEventListener('dragover',  e => { e.preventDefault(); dropZone.classList.add('drag'); });
  dropZone.addEventListener('dragleave', ()  => dropZone.classList.remove('drag'));
  dropZone.addEventListener('drop', e => {
    e.preventDefault();
    dropZone.classList.remove('drag');
    const f = e.dataTransfer.files[0];
    if (f) { currentDemo = DEMOS['k562_del']; showToast('File loaded: ' + f.name); }
  });
}
